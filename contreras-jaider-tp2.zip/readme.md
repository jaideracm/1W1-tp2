# TP 2 - Mise en Page Web
## HockeyStiques
Page web sur les nouvelles du hockey sur glace et la LNH.

- Auteur : Jaider Contreras
- Cours : 1W1 Mise en Page Web
- Github-page : https://jaideracm.github.io/1W1-tp2/
